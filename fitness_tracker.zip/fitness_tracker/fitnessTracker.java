import java.util.*;
import java.text.DecimalFormat;
import java.io.*;
import java.nio.file.*;

class Display {
    String username;
    int age;
    double height;
    double weight;
    char gender;
    String space = "                                                                                                                                           ";

    Display(){}
    
    Display(String username, int age, double height, double weight, char gender) {
        this.username = username;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.gender = gender;
    }

    void displayInfo() {
    	Scanner scanner = new Scanner(System.in);
    	DecimalFormat decimalFormat = new DecimalFormat("0.##");


        Calculate calc = new Calculate();
        Cardio cardioExercise = new Cardio(weight);
   		WorkoutPlan workoutsCall = new WorkoutPlan();
   		System.out.println("                                                             ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("                                                             ┃                                      ┃");
        System.out.println("                                                             ┃      \u001B[1m1. Fitness Calculator\u001B[0m           ┃");
        System.out.println("                                                             ┃      \u001B[1m2. Cardio Calorie Burn Tracker\u001B[0m  ┃");
        System.out.println("                                                             ┃      \u001B[1m3. Workouts\u001B[0m                     ┃"); 
        System.out.println("                                                             ┃      \u001B[1m4. Diet Plans\u001B[0m                   ┃");
        System.out.println("                                                             ┃      \u001B[1m5. Nutrients Analysis\u001B[0m           ┃");
        System.out.println("                                                             ┃                                      ┃");
        System.out.println("                                                             ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
        System.out.print("\n                                                              Enter: ");

        int homeChoice = scanner.nextInt();

        System.out.println("\n\n");
        loop : while(true){
            if (homeChoice == 1){
                callingCalculator();
                break loop;
            }
            	
        	else if (homeChoice == 2){
        		callingCardio();
                break loop;
        	}
        	else if (homeChoice == 3) {
        		callingWorkouts();
                break loop;   		
        	}
            else if (homeChoice == 4) {
                callingdiet();
                break loop;
            }
            else if (homeChoice == 5) {
                
                calorieTracker a = new calorieTracker();
                a.track();
                break loop;
            }
            else {
                System.out.println("Please enter the correct option.");
                homeChoice = scanner.nextInt();
            }
        }   
    }

    void exitCalculate(){
        Scanner scanner = new Scanner(System.in);
        System.out.println(space + "------------------");
        System.out.println(space + ":     1.Back     :");
        System.out.println(space + ":     2.Exit     :");
        System.out.println(space + "------------------");   
        System.out.print(space + "Enter: ");

        int exitChoice = scanner.nextInt();

        if(exitChoice == 1){
            callingCalculator();
        }
        else if (exitChoice == 2) {
            System.out.print("");
        }
    }

    void exitCardio(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("");
        System.out.println(space + "------------------");
        System.out.println(space + ":     1.Back     :");
        System.out.println(space + ":     2.Exit     :");
        System.out.println(space + "------------------");   
        System.out.print(space + "Enter: ");

        int exitChoice = scanner.nextInt();

        if(exitChoice == 1){
            callingCardio();
        }
        else if (exitChoice == 2) {
            System.out.print("");
        }
    }

    void exitWorkout(){
        Scanner scanner = new Scanner(System.in);
        System.out.println(space + "------------------");
        System.out.println(space + ":     1.Back     :");
        System.out.println(space + ":     2.Exit     :");
        System.out.println(space + "------------------");   
        System.out.print(space + "Enter: ");

        int exitChoice = scanner.nextInt();

        if(exitChoice == 1){
            callingWorkouts();
        }
        else if (exitChoice == 2) {
            System.out.print("");
        }        
    }

    void exitDiet(){
        Scanner scanner = new Scanner(System.in);
        System.out.println(space + "------------------");
        System.out.println(space + ":     1.Back     :");
        System.out.println(space + ":     2.Exit     :");
        System.out.println(space + "------------------");   
        System.out.print(space + "Enter: ");

        int exitChoice = scanner.nextInt();

        if(exitChoice == 1){
            callingdiet();
        }
        else if (exitChoice == 2) {
            System.out.print("");
        }
    }

    void callingCalculator(){
        Scanner scanner = new Scanner(System.in);
        Calculate calc = new Calculate();
        DecimalFormat decimalFormat = new DecimalFormat("0.##");

        System.out.println(" ╔═════════════════════════════════════════════╗");
        System.out.println(" ║                                             ║");
        System.out.println(" ║   1. Calculate your BMI                     ║");
        System.out.println(" ║   2. Calculate your maintenance calorie     ║");
        System.out.println(" ║   3. Approximate weight for your height     ║");
        System.out.println(" ║                                             ║");
        System.out.println(" ╚═════════════════════════════════════════════╝");


        System.out.println(space + "------------------");
        System.out.println(space + ":     4.Back     :");
        System.out.println(space + ":     5.Exit     :");
        System.out.println(space + "------------------");   

        System.out.print("\nEnter your choice: ");
        int calculateChoice = scanner.nextInt();

        if(calculateChoice == 4){
            displayInfo();
        }
        else if (calculateChoice == 5) {
            // System.out.print("");
        }

        if (calculateChoice == 1){    // BMI

            double bmi = calc.calcBMI(weight, height);
            System.out.println(" ___________________________________________________________________");
            System.out.println("|  _______________________________________________________________  |");
            System.out.println("| |                                                               | |");
            System.out.println("| |              Your Body mass index(BMI) is: " + (decimalFormat.format(bmi)) + "              | |");


            if ((bmi >= 18.5) && (bmi <= 24.9)){
                System.out.println("| |              You have a normal body weight.                   | |");
            }   
            else if (bmi < 18.5) {
                System.out.println("| |              You are underweight.                             | |");
            }
            else if ((bmi > 24.9) && (bmi < 30)){
                System.out.println("| |              You are overweight.                              | |");
            }
            else {
                System.out.println("| |              You are obese.                                   | |");
            }
            System.out.println("| |_______________________________________________________________| |");
            System.out.println("|___________________________________________________________________|");

            exitCalculate();
        }
        else if( calculateChoice == 2){    // maintenance calorie

            String patternBeg = " ___________________________________________________________________\n|  _______________________________________________________________  |\n| |                                                               | |";
           
            System.out.println( patternBeg + "\n| |        This is your maintenance calorie: " + (decimalFormat.format(calc.calcMaintenanceCalories(weight, height, age, gender))) + " kcal         | |");
            System.out.println("| |_______________________________________________________________| |");
            System.out.println("|___________________________________________________________________|");

            exitCalculate();
        }
        else if( calculateChoice == 3) {  // approximate weight
            calc.correctWeight(height);
            exitCalculate();
        }
    }

    void callingCardio(){
        Cardio cardioExercise = new Cardio(weight);
        Scanner scanner = new Scanner(System.in);
        DecimalFormat decimalFormat = new DecimalFormat("0.##");
            System.out.println(" ╔═════════════════╗");
            System.out.println(" ║                 ║");
            System.out.println(" ║  1. Running     ║");
            System.out.println(" ║  2. Cycling     ║");
            System.out.println(" ║  3. Swimming    ║");
            System.out.println(" ║  4. Jogging     ║");
            System.out.println(" ║  5. Walking     ║");
            System.out.println(" ║                 ║");
            System.out.println(" ╚═════════════════╝");


            System.out.println(space + "------------------");
            System.out.println(space + ":     6.Back     :");
            System.out.println(space + ":     7.Exit     :");
            System.out.println(space + "------------------");   

            System.out.print("\nEnter: ");

            int cardioChoice = scanner.nextInt();

            String patternBeg = " ____________________________________________________\n|  ________________________________________________  |\n| |                                                | |\n| |     ";
            String patternEnd = "\n| |________________________________________________| |\n|____________________________________________________|" ;
            System.out.println("");

            if(cardioChoice == 1){ 
                System.out.printf("%-8s %-32s %-8d %3s", patternBeg , "You burnt calories by running: " , cardioExercise.running() , "| |");         
                System.out.println(patternEnd);
                exitCardio();   
            }
            else if (cardioChoice == 2){
                System.out.printf("%-8s %-32s %-8d %3s", patternBeg , "You burnt calories by cycling: " , cardioExercise.cycling() , "| |");   
                System.out.println(patternEnd);
                exitCardio();                           
            }
            else if (cardioChoice == 3){ 
                System.out.printf("%-8s %-32s %-8d %3s", patternBeg , "You burnt calories by swimming: " , cardioExercise.swimming() , "| |");  
                System.out.println(patternEnd);
                exitCardio();        
            } 
            else if (cardioChoice == 4){
                System.out.printf("%-8s %-32s %-8d %3s", patternBeg , "You burnt calories by jogging: " , cardioExercise.jogging() , "| |");    
                System.out.println(patternEnd);
                exitCardio();               
            }
            else if (cardioChoice == 5){
                System.out.printf("%-8s %-32s %-8d %3s", patternBeg , "You burnt calories by walking: " , cardioExercise.walking() , "| |");    
                System.out.println(patternEnd);
                exitCardio();                    
            }  

            if(cardioChoice == 6){
                displayInfo();
            }       
            else if (cardioChoice == 7) {
                // System.out.println("");
            }
    }

    void callingWorkouts(){
        Scanner scanner = new Scanner(System.in);
        WorkoutPlan workoutsCall = new WorkoutPlan();
        DecimalFormat decimalFormat = new DecimalFormat("0.##");

        System.out.println(" ╔══════════════════╗");
        System.out.println(" ║                  ║");
        System.out.println(" ║   1. Arms        ║");
        System.out.println(" ║   2. Six pack    ║");
        System.out.println(" ║   3. Chest       ║");
        System.out.println(" ║   4. Leg         ║");
        System.out.println(" ║   5. Back        ║");
        System.out.println(" ║                  ║");
        System.out.println(" ╚══════════════════╝");


        System.out.println(space + "------------------");
        System.out.println(space + ":     6.Back     :");
        System.out.println(space + ":     7.Exit     :");
        System.out.println(space + "------------------");

        System.out.print("\nEnter: ");

        int workoutChoice = scanner.nextInt();

        if(workoutChoice == 1){
            workoutsCall.armWorkout();
            exitWorkout();
        }
        else if (workoutChoice == 2) {
            workoutsCall.absWorkout();
            exitWorkout();
        }
        else if (workoutChoice == 3) {
            workoutsCall.chestWorkout();
            exitWorkout();
        }
        else if (workoutChoice == 4) {
            workoutsCall.legWorkout();
            exitWorkout();
        }
        else if (workoutChoice == 5){
            workoutsCall.backWorkout();
            exitWorkout();
        } 
        else if (workoutChoice == 6) {
            displayInfo();
        }           
    }

    void callingdiet(){
        Scanner scanner = new Scanner(System.in);

        DietPlans dietCall = new DietPlans();

        System.out.println(" ╔══════════════════════╗");
        System.out.println(" ║                      ║");
        System.out.println(" ║    1. Weight loss    ║");
        System.out.println(" ║    2. Weight gain    ║");
        System.out.println(" ║                      ║");
        System.out.println(" ╚══════════════════════╝");


        System.out.println(space + "------------------");
        System.out.println(space + ":     3.Back     :");
        System.out.println(space + ":     4.Exit     :");
        System.out.println(space + "------------------");   

        System.out.print("\nEnter: ");

        int dietChoice = scanner.nextInt();

        if(dietChoice == 1){
            dietCall.cutting();
            exitDiet();
        }
        else if (dietChoice == 2) {
            dietCall.bulk();
            exitDiet();
        }
        else if (dietChoice == 3) {
            displayInfo();
        }
        else{
            System.out.println("");
        }      
    }
}

class Calculate {

    double calcBMI(double weight, double height) {
        double heightInMeters = height / 100;	
        return (weight / (heightInMeters * heightInMeters));
    }

    double calcMaintenanceCalories(double weight, double height, int age, char gender) {
        double bmrMale = 88.362;
        double bmrFemale = 447.593;
        double weightFactor = 13.297;
        double heightFactor = 4.299;
        double ageFactor = 5.677;
        double bmr = 0.0;

        if (gender == 'M' || gender == 'm') {
            bmr = bmrMale + (weightFactor * weight) + (heightFactor * height) - (ageFactor * age);
        } else if (gender == 'F' || gender == 'f') {
            bmr = bmrFemale + (weightFactor * weight) + (heightFactor * height) - (ageFactor * age);
        }

        double maintenanceCalories = bmr * getActivityMultiplier();

        return maintenanceCalories;
    }

    double getActivityMultiplier() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nSelect your activity level:");
        System.out.println("1. Sedentary (little or no exercise)");
        System.out.println("2. Lightly active (light exercise/sports 1-3 days/week)");
        System.out.println("3. Moderately active (moderate exercise/sports 3-5 days/week)");
        System.out.println("4. Very active (hard exercise/sports 6-7 days a week)");
        System.out.println("5. Extremely active (very hard exercise/sports & physical job or 2x training)");

        System.out.print("\nEnter the number corresponding to your activity level: ");
        int activityLevel = scanner.nextInt();


        switch (activityLevel) {
            case 1:
                return 1.2;
            case 2:
                return 1.375;
            case 3:
                return 1.55;
            case 4:
                return 1.725;
            case 5:
                return 1.9;
            default:
                System.out.println("Invalid input. Using a Lightly activity level.");
                return 1.375;
        }
    }

    void correctWeight(double height){

    	double heightInMeters = height / 100;		
        int lowerWeight = (int) (18.5 * (heightInMeters * heightInMeters));
        int upperWeight = (int) (24.9 * (heightInMeters * heightInMeters));

        System.out.println(" ______________________________________ ");
        System.out.println("|  __________________________________  |");
        System.out.println("| |                                  | |");
        System.out.println("| | Weight limit:                    | |");
        System.out.println("| |	    Lower limit: " + ((lowerWeight)) + " kg	     | |");
        System.out.println("| |	    Upper limit: " + ((upperWeight)) + " kg	     | |");
        System.out.println("| |__________________________________| |");
        System.out.println("|______________________________________|");
    }
}

class Cardio {
	Scanner scanner = new Scanner(System.in);
	double weight;
	double speedKph;
	double timeMin;
    double met;

	Cardio(double weight){
		this.weight = weight;								
	}

	int running() {
        System.out.println("\nPlease enter the speed at which you run. (km/h)");
        speedKph = scanner.nextDouble();
        System.out.println("Please enter the time you spend for running(in minutes).");
        timeMin = scanner.nextDouble();
        if (speedKph < 8.0) {
            met = 7.0;
        } else if ((speedKph > 8.0) && (speedKph < 12.0)) {
            met = 9.0;
        } else {
            met = 12.0;
        }

        return (int) (met * weight * (timeMin/60));	
	}

	int cycling() {
        System.out.println("\nPlease enter the cycling speed (km/h)");
        speedKph = scanner.nextDouble();
        System.out.println("Please enter the time you spend for cycling(in minutes).");
        timeMin = scanner.nextDouble();
        if (speedKph < 10.0) {
            met = 4.0;
        } else if ((speedKph > 10.0) && (speedKph < 15.0)) {
            met = 6.0;
        } else {
            met = 8.0;
        }

        return (int) (met * weight * (timeMin/60));
	}

	int swimming(){
		System.out.println("\nEnter swimming style (e.g: freestyle: ");
        String swimmingStyle = scanner.next();
        System.out.println("Enter swimming duration (in minutes): ");
        timeMin = scanner.nextDouble();

        if (swimmingStyle.equals("freestyle")){
        	met = 7.0;
        }
        else if(swimmingStyle.equals("breaststroke")){
        	met = 5.0;
        }
        else{
        	// System.out.println("Invalid swimming style. Using default MET value.");
        	met = 6.0;
        }

        return (int) (met * weight * (timeMin/60));
	}

	int jogging() {
        System.out.println("\nPlease enter the speed at which you are jogging. (km/h)");
        speedKph = scanner.nextDouble();
        System.out.println("Please enter the time you spend for jogging(in minutes).");
        timeMin = scanner.nextDouble();
        if (speedKph < 6.0) {
            met = 7.0;
        } else if ((speedKph > 6.0) && (speedKph < 8.0)) {
            met = 9.0;
        } else {
            met = 9.8;
        }

        return (int) (met * weight * (timeMin/60));
	}

	int walking() {
        System.out.println("\nPlease enter the speed at which you are walking. (km/h)");
        speedKph = scanner.nextDouble();
        System.out.println("Please enter the time you spend for walking(in minutes).");
        timeMin = scanner.nextDouble();
        if (speedKph < 2.0) {
            met = 2.0;
        } else if ((speedKph > 2.0) && (speedKph < 3.0)) {
            met = 2.8;
        } else {
            met = 3.5;
        }

        return (int) (met * weight * (timeMin/60));
	}
}

class WorkoutPlan {
	ArrayList<String> bicepWorkouts = new ArrayList<>();
	ArrayList<String> tricepWorkouts = new ArrayList<>();
	ArrayList<String> sixpackWorkouts = new ArrayList<>();
	ArrayList<String> chestWorkouts = new ArrayList<>();
	ArrayList<String> legWorkouts = new ArrayList<>();
	ArrayList<String> backWorkouts = new ArrayList<>();

    void printWorkouts(ArrayList<String> workouts, String category) {

        System.out.println(" ________________________________________________");
        System.out.println("|  ____________________________________________  |");
        System.out.println("| |                                            | |");
        System.out.printf("%-7s %-38s %-5s\n",  "| |", category, "| |");
        System.out.println("| | ------------------------------------------ | |"); 

        for (String workout : workouts) {
            System.out.printf("%-10s %-35s %-5s\n", "| |" , workout, "| |");
        }

        System.out.println("| |____________________________________________| |");
        System.out.println("|________________________________________________|");
    }

	void armWorkout(){
		System.out.println("\n    Bicep workouts: \n");
		bicepWorkout();
		System.out.println("\n    Tricep workouts: \n");
		tricepWorkout();
        printWorkouts(bicepWorkouts, "Bicep workouts:");
        printWorkouts(tricepWorkouts, "Tricep workouts:");
	}
	void bicepWorkout(){

        bicepWorkouts.add("Barbell Curl");
        bicepWorkouts.add("Dumbbell Curl");
        bicepWorkouts.add("Hammer Curl");
        bicepWorkouts.add("Spider Curl");
        bicepWorkouts.add("Concentration Curl");
        bicepWorkouts.add("Incline Dumbbell Curl");
        bicepWorkouts.add("Cable Curl");
        bicepWorkouts.add("Reverse Curl");
        bicepWorkouts.add("EZ-Bar Curl");
        bicepWorkouts.add("21s");
	}
	void tricepWorkout(){

        tricepWorkouts.add("Tricep Dips");
        tricepWorkouts.add("Tricep Pushdown");
        tricepWorkouts.add("Close-Grip Bench Press");
        tricepWorkouts.add("Skull Crushers");
        tricepWorkouts.add("Overhead Dumbbell Extension");
        tricepWorkouts.add("Tricep Kickbacks");
        tricepWorkouts.add("Diamond Push-Ups");
        tricepWorkouts.add("Rope Tricep Pushdown");
        tricepWorkouts.add("Tricep Overhead Cable Extension");
        tricepWorkouts.add("Reverse Grip Tricep Pushdown");
	}

	void absWorkout(){


        sixpackWorkouts.add("Crunches");
        sixpackWorkouts.add("Reverse Crunches");
        sixpackWorkouts.add("Leg Raises");
        sixpackWorkouts.add("Russian Twists");
        sixpackWorkouts.add("Plank");
        sixpackWorkouts.add("Side Plank");
        sixpackWorkouts.add("Mountain Climbers");
        sixpackWorkouts.add("Bicycle Crunches");
        sixpackWorkouts.add("Hanging Leg Raises");
        sixpackWorkouts.add("Sit-Ups");
        sixpackWorkouts.add("Flutter Kicks");
        sixpackWorkouts.add("Woodchoppers");
        sixpackWorkouts.add("Ab Rollouts");
        sixpackWorkouts.add("V-Ups");
        sixpackWorkouts.add("Dragon Flags");
        sixpackWorkouts.add("Scissor Kicks");
        sixpackWorkouts.add("Hollow Body Hold");
        sixpackWorkouts.add("Windshield Wipers");
        sixpackWorkouts.add("Plank Hip Dips");
        sixpackWorkouts.add("Dead Bug Exercise");

        
        printWorkouts(sixpackWorkouts, "Six-pack workouts:");
	} 

	void chestWorkout(){

        chestWorkouts.add("Bench Press");
        chestWorkouts.add("Dumbbell Flyes");
        chestWorkouts.add("Incline Bench Press");
        chestWorkouts.add("Decline Bench Press");
        chestWorkouts.add("Push-Ups");
        chestWorkouts.add("Chest Dips");
        chestWorkouts.add("Chest Press Machine");
        chestWorkouts.add("Pec Deck Machine");
        chestWorkouts.add("Cable Crossover");
        chestWorkouts.add("Dumbbell Pullover");
        chestWorkouts.add("Landmine Press");
        chestWorkouts.add("Guillotine Press");
        chestWorkouts.add("Incline Dumbbell Flyes");
        chestWorkouts.add("Machine Flyes");
        chestWorkouts.add("Chest Squeeze Press");
        chestWorkouts.add("Bodyweight Chest Press");
        chestWorkouts.add("Smith Machine Bench Press");
        chestWorkouts.add("Chest Press with Resistance Bands");
        chestWorkouts.add("One-Arm Dumbbell Bench Press");
        chestWorkouts.add("Plyometric Push-Ups");

        
        printWorkouts(chestWorkouts, "Chest workouts:");
	}

	void legWorkout(){
        legWorkouts.add("Squats");
        legWorkouts.add("Deadlifts");
        legWorkouts.add("Lunges");
        legWorkouts.add("Leg Press");
        legWorkouts.add("Leg Extensions");
        legWorkouts.add("Leg Curls");
        legWorkouts.add("Calf Raises");
        legWorkouts.add("Box Jumps");
        legWorkouts.add("Step-Ups");
        legWorkouts.add("Hack Squats");
        legWorkouts.add("Sumo Squats");
        legWorkouts.add("Bulgarian Split Squats");
        legWorkouts.add("Romanian Deadlifts");
        legWorkouts.add("Walking Lunges");
        legWorkouts.add("Seated Leg Press");
        legWorkouts.add("Dumbbell Step-Ups");
        legWorkouts.add("Hamstring Curls");
        legWorkouts.add("Good Mornings");
        legWorkouts.add("Quad Extensions");
        legWorkouts.add("Wall Sit");

       
        printWorkouts(legWorkouts, "Leg workouts:");
	}

	void backWorkout(){
        backWorkouts.add("Deadlifts");
        backWorkouts.add("Bent Over Rows");
        backWorkouts.add("Pull-Ups");
        backWorkouts.add("Lat Pulldowns");
        backWorkouts.add("Seated Cable Rows");
        backWorkouts.add("T-Bar Rows");
        backWorkouts.add("Face Pulls");
        backWorkouts.add("Single-Arm Dumbbell Rows");
        backWorkouts.add("Chin-Ups");
        backWorkouts.add("Hyperextensions (Back Extensions)");
        backWorkouts.add("Wide-Grip Pull-Ups");
        backWorkouts.add("Close-Grip Pulldowns");
        backWorkouts.add("Pendlay Rows");
        backWorkouts.add("Inverted Rows");
        backWorkouts.add("Lat Pulldowns Behind the Neck");
        backWorkouts.add("Machine Rows");
        backWorkouts.add("Shrugs");
        backWorkouts.add("Single-Arm Lat Pulldowns");
        backWorkouts.add("Rack Pulls");
        backWorkouts.add("Renegade Rows");

        printWorkouts(backWorkouts, "Back workouts:");
	}
}

class DietPlans{


	void cutting(){
        String[] dishArray1 = {
            "Green gram dosa","Oats upma", "Ragi dosa", "Soya chunks fried rice", "Soya chunks stir fry", "Millet ven pongal", "Chicken sandwich", "Soya and veg pulao", "Chapati with chicken", "Soya kebabs", "Mixed bean and pomegranate salad", "Whey protein"
        };

        String[] calorieArray1 = {"100.3", "225", "160", "515", "273.6", "269", "483", "323", "398", "225", "421", "75"};
        String[] proteinArray1 = {"5.4", "9", "7", "31.3", "25.1", "11", "33", "15", "30", "20", "25", "13"};
        String[] fatsArray1 = {"1.6", "7", "3", "19", "12", "8", "4.8", "10", "15", "11", "4.24", "1"};
        String[] carbsArray1 = {"16.1", "33", "27", "70", "20", "43.5", "75", "44.9", "32", "16", "71.7", "3.5"};
        
        System.out.println("╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗");
        System.out.printf("║ %-35s %-15s %-15s %-15s %-20s ║ \n", "Foods", "Calories", "Proteins", "Fats", "Carbohydrates");
        System.out.println("║══════════════════════════════════════════════════════════════════════════════════════════════════════════║");
        System.out.println("║                                                                                                          ║");
        for (int i = 0; i < dishArray1.length; i++) {
            System.out.printf("║ %-35s %-15s %-15s %-20s %-15s ║ \n", dishArray1[i], calorieArray1[i], proteinArray1[i], fatsArray1[i], carbsArray1[i]);
        }
        System.out.println("╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝");
	}

	void bulk(){

        String[] dishArray2 = {
            "Peanut butter sandwich", "Chicken curry", "Soya curry", "Panneer sandwich", "Chicken keema frankie", "Chapati with Panneer", "Sweet potato salad", "Channa salad", "Chicken sandwich", "Chapati Egg bhurji", "Whey protein", "Potato egg white Omelette"
        };

        String[] calorieArray2 = {"516", "521", "506", "826", "514", "750", "473", "509", "483", "546","75", "480"};
        String[] proteinArray2 = {"22", "38.3", "30.5", "50", "48", "58", "17.1", "26.5", "33", "44","13", "43"};
        String[] fatsArray2 = {"26.5", "5.6", "9.1", "42.1", "19", "25", "21.1", "6.9", "4.8", "22","1", "10.4"};
        String[] carbsArray2 = {"50.3", "80.8", "76.8","62.4","35", "96.8", "64.9", "85.9", "75", "46","3.5", "52"};

        System.out.println("╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗");
        System.out.printf("║ %-35s %-15s %-15s %-15s %-20s ║ \n", "Foods", "Calories", "Proteins", "Fats", "Carbohydrates");
        System.out.println("║══════════════════════════════════════════════════════════════════════════════════════════════════════════║");
        System.out.println("║                                                                                                          ║");
        for (int i = 0; i < dishArray2.length; i++) {
            System.out.printf("║ %-35s %-15s %-15s %-20s %-15s ║ \n", dishArray2[i], calorieArray2[i], proteinArray2[i], fatsArray2[i], carbsArray2[i]);
        }
        System.out.println("╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝");

	}
}

class calorieTracker{
    void track() {
        Scanner scanner = new Scanner(System.in);

        List<String> foodList = Arrays.asList(
                "bread omelette","peanut butter sandwich","chicken curry","soya curry","panneer sandwich","chicken keema frankie","chapati with panneer","sweet potato salad","channa salad","chicken sandwich","chapati egg bhurji","whey protein","potato egg white omelette","green gram dosa", "oats upma", "ragi dosa", "soya chunks fried rice", "soya chunks stir fry", "millet ven pongal", "chicken sandwich", "soya and veg pulao", "chapati with chicken", "soya kebabs",  "mixed bean and pomegranate salad", "chapati", "chicken biryani", "veg fried rice", "sambar rice", "curd rice", "parotta", "egg fried rice", "chicken rice", "veg biryani", "idli", "dosa", "poori", "idiyappam", "pazhaya soru", "wheat parotta", "white rice", "samba rice", "mint rice", "butter milk", "lemon rice"
        );

        List<String> calorieList = Arrays.asList("356", "516", "521", "506", "826", "514", "750", "473", "509", "483", "546", "75", "480", "100.3", "225", "160", "515", "273.6", "269", "483", "323", "398", "225", "421", "71", "498", "279", "214", "207", "258", "238", "288", "622", "69", "130", "80", "70", "133", "125", "194", "207", "177", "9", "176");
        List<String> proteinList = Arrays.asList("18.4", "22", "38.3", "30.5", "50", "48", "58", "17.1", "26.5", "33", "44", "13", "43", "5.4", "9", "7", "31.3", "25.1", "11", "33", "15", "30", "20", "25", "3", "16", "8", "6.5", "6.1", "5", "6", "19", "14.2", "1.2", "4.6", "1", "1" , "2", "1.1", "4.6", "4", "4.7", "0.5", "5");
        List<String> fatsList = Arrays.asList("16.3", "26.5", "5.6", "9.1", "42.1", "19", "25", "21.1", "6.9", "4.8", "22", "1", "10.4", "1.6", "7", "3", "19", "12", "8", "4.8", "10", "15", "11", "4.24", "0.4", "8", "14", "4.5", "3.2", "10", "4.1", "12", "23.5", "0.2", "14.4", "2.5", "2.3", "0.5", "3.7", "3.7", "0.6", "3.2", "2.2", "0.5", "2");
        List<String> carbsList = Arrays.asList("33.4" ,"50.3", "80.8", "76.8", "62.4", "35", "96.8", "64.9", "85.9", "75", "46", "3.5", "52", "16.1", "33", "27", "70", "20", "43.5", "75", "44.9", "32", "16", "71.7", "15", "56", "30", "39", "38", "36", "45", "25", "78.9", "15", "36", "12", "10.9", "20", "19.7", "42", "37.6", "5", "0.7", "34");

        System.out.print("Enter the food: ");   
        String food = scanner.nextLine();

        food = food.toLowerCase();

        while (true) {
            if (foodList.contains(food)) {
                break;
            } else {
                System.out.println("\nSorry, I do not have " + food + " in the list. Please enter a food from the list.\n");
                System.out.println(foodList + "\n\nPlease enter a food: ");
                food = scanner.nextLine();
            }
        }

        int indexOfFood = foodList.indexOf(food);
        System.out.println("\n");
        System.out.println("╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗");
        System.out.printf( "║ %-35s %-15s %-15s %-15s %-20s ║ \n", "Foods", "Calories", "Proteins", "Fats", "Carbohydrates");
        System.out.println("║══════════════════════════════════════════════════════════════════════════════════════════════════════════║");
        System.out.println("║                                                                                                          ║");
        System.out.printf( "║ %-35s %-15s %-15s %-20s %-15s ║ \n", foodList.get(indexOfFood), calorieList.get(indexOfFood), proteinList.get(indexOfFood), fatsList.get(indexOfFood), carbsList.get(indexOfFood));
        System.out.println("╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝");


        System.out.println("                                                                                                                                           ------------------");
        System.out.println("                                                                                                                                           :     1.Back     :");
        System.out.println("                                                                                                                                           :     2.Exit     :");
        System.out.println("                                                                                                                                           ------------------");   
        System.out.print("                                                                                                                                           Enter: ");

        int exitChoice = scanner.nextInt();

        Display user = new Display();

        if(exitChoice == 1){
            user.displayInfo();
        }
        else if (exitChoice == 2) {
            System.out.print("");
        }
    }
}

class fitnessTracker {
    static ArrayList<String> userNameList = new ArrayList<>();
    static ArrayList<String> userPasswordList = new ArrayList<>();
    static ArrayList<String> fileContents = new ArrayList<>();
    static String loginFile = "";

    String currentUser;
 
    public static void main(String[] args) throws Exception{   
        Scanner scanner = new Scanner(System.in);
        

        System.out.println("\n                                                     █▀▀ █ ▀█▀ █▄ █ █▀▀ █▀ █▀   ▀█▀ █▀█ █▀█ █▀▀ █▄▀ █▀▀ █▀█"+ 
                           "\n                                                     █▀  █  █  █ ▀█ ██▄ ▄█ ▄█    █  █▀▄ █▀█ █▄▄ █ █ ██▄ █▀▄");

        String loginFile = "loginFile.txt";

            List<String> fileContents = Files.readAllLines(Paths.get(loginFile));
            FileWriter userfile = new FileWriter(loginFile, true);


            for (String line : fileContents) {
                String[] userDetails = line.split("~");
                if (userDetails.length >= 1) {
                    String tempUsername = userDetails[0];
                    userNameList.add(tempUsername);

                    String tempPassword = userDetails[0];
                    userPasswordList.add(tempPassword);
                }
            }

        fitnessTracker main = new fitnessTracker();
        System.out.println("╔═════════════════╗");
        System.out.println("║   1. Sign-up    ║");
        System.out.println("║   2. Sign-in    ║");
        System.out.println("╚═════════════════╝");


        System.out.print("Enter: ");

        int signChoice = scanner.nextInt();

        sign : while(true){
            if (signChoice == 1){   
                main.signUp();
                break sign;
            }
            else if(signChoice == 2){
                main.signIn();
                break sign;
            }
            else if(signChoice == 99){
                Display user = new Display("mathi", 17, 175, 60, 'm');
                user.displayInfo();
            }
            else {
                System.out.println("Please enter the correct option.");
                signChoice = scanner.nextInt();
            }
        }
    }

   
    void signUp(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("\n\nEnter the username: ");
        String username = scanner.nextLine();

        System.out.print("Enter the password: ");
        String password = scanner.nextLine();
        System.out.print("Enter the confirm password: ");
        String confirmPassword = scanner.nextLine();

        while(true){
            if (confirmPassword.equals(password)){
                break;
            }
            else {
                System.out.println("\u001B[31mInvalid password. Please enter comfirm password.\u001B[0m");
                confirmPassword = scanner.next();
            }
        }       

        try{

            String loginFile = "loginFile.txt";

            List<String> fileContents = Files.readAllLines(Paths.get(loginFile));
            FileWriter userfile = new FileWriter(loginFile, true);


            userfile.write(username + "~" + password + "\n");
            userfile.close();

            if (userNameList.contains(username)) {
                System.out.println("\u001B[31mUsername already exist. Please enter another username.\u001B[0m:");
            }
            else {

                System.out.print("\nEnter your full name: ");
                String userName = scanner.next();
                System.out.print("Enter your age: ");
                int userAge = scanner.nextInt();
                System.out.print("Enter your height (cm): ");
                double height = scanner.nextDouble();
                System.out.print("Enter your weight (kg): ");
                double weight = scanner.nextDouble();
                System.out.print("Enter your gender (M/F): ");
                char gender = scanner.next().charAt(0);

                while (true) {
                    if ((gender != 'M') && (gender != 'm') && (gender != 'F') && (gender != 'f')) {
                        System.out.println("Invalid gender input. Please enter 'M' or 'F'.");
                        gender = scanner.next().charAt(0);
                    } else {
                        break;  
                    }
                }
                String fileName = "";
                try {
                    fileName = userName + ".txt";
                    File userFile = new File(fileName); 

                        FileWriter userDetailsFileInput = new FileWriter(fileName, true);

                        userDetailsFileInput.write(userName + "~" + userAge + "~" + height + "~" + weight + "~" + gender + "\n");
                        userDetailsFileInput.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    String[] userDetails = Files.readAllLines(Paths.get(fileName)).get(0).split("~");
                    // System.out.println(Arrays.toString(userDetails));
                    Display user = new Display(userDetails[0], Integer.parseInt(userDetails[1]),
                        Double.parseDouble(userDetails[2]), Double.parseDouble(userDetails[3]),
                        userDetails[4].charAt(0));

                    user.displayInfo();
                } catch (IOException e) {
                    e.printStackTrace(); 
                }
            }
        }
        catch (IOException e) {
            System.out.println("hello error");
            e.printStackTrace();
        }
    }

    void signIn(){

        Scanner scanner = new Scanner(System.in);

        System.out.print("\n\nEnter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        int index = userNameList.indexOf(username); 

        if (index != -1 && userPasswordList.get(index).equals(password)) {
            System.out.println("\u001B[32mSign in successful!\u001B[0m");
            try {
                String fileName = username + ".txt";
                String[] userDetails = Files.readAllLines(Paths.get(fileName)).get(0).split("~");

                // System.out.println(Arrays.toString(userDetails));
                Display user = new Display(userDetails[0], Integer.parseInt(userDetails[1]),
                    Double.parseDouble(userDetails[2]), Double.parseDouble(userDetails[3]),
                    userDetails[4].charAt(0));

                user.displayInfo();
            } catch (IOException e) {
                e.printStackTrace(); 
            }

        } else {
            System.out.println("\u001B[31mInvalid username or password. Please try again.\u001B[0m");
        }       
    }
}